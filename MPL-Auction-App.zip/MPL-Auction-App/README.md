# Auction (Auction Tracker app)
Push to GitHub -> Actions -> Build APK.
